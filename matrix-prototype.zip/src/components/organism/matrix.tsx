import React from "react";
import { Layer, Line, Stage } from "react-konva";
import { useDispatch, useSelector } from "react-redux";
import { getAllUsers } from "../../redux/reducers/rect";
import { Rect } from "../molecules/rect";
import { getStateByWeek } from "../utils/userlookup";

export const Matrix = () => {
  const rects: Array<JSX.Element> = [];
  const dispatch = useDispatch();
  const storeRects = useSelector(getAllUsers);
  let i = 0;
  let y = 0;
  storeRects.forEach((user) => {
    rects.push(
      <Line
        points={[0, 1, 10 * 90, 1]}
        stroke={"#DDD"}
        strokeWidth={0.7}
      ></Line>
    );
    for (let x = 0; x < 10; x++) {
      rects.push(
        <Rect
          userid={y}
          week={x + 1}
          year={2020}
          state={getStateByWeek(user, x + 1)}
          offsetX={x}
          offsetY={y}
          index={i}
          key={"matrix_rect_" + y + "_" + 2020 + "_" + (x + 1)}
          dispatch={dispatch}
        ></Rect>
      );
      i++;
      rects.push(
        <Line
          points={[0, i * 90, 10 * 90, i * 90]}
          stroke={"#DDD"}
          strokeWidth={0.7}
        ></Line>
      );
    }
    y++;
  });
  console.log(rects);
  return (
    <Stage
      width={90 * 10}
      height={90 * 100}
      style={{
        marginLeft: (window.innerWidth - 90 * 10) / 2 + "px",
        marginTop: "40px",
      }}
    >
      <Layer>{rects}</Layer>
    </Stage>
  );
};
