export const getStatebyUserAndWeek = (
  state: Map<number, Map<number, number>>,
  user: number,
  week: number
) => {
  let status = state.get(user);
  if (status !== undefined) {
    let ajState = status.get(week);
    if (typeof ajState == "number") return ajState;
  }
  return -1;
};

export const getStateByWeek = (user: Map<number, number>, week: number) => {
  let state = user.get(week);
  if (typeof state == "number") return state;
  return -1;
};
