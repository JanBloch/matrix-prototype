import { Dispatch } from "react";

export interface Rect {
  users: Map<number, Map<number, number>>;
  index: number;
}

export interface RectProps {
  week: number;
  year: number;
  userid: number;
  state: number;
  offsetX: number;
  offsetY: number;
  index: number;
  dispatch: Dispatch<any>;
}

export interface InitProps {
  index: number;
  state: number;
}
