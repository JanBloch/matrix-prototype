import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { getStatebyUserAndWeek } from "../../components/utils/userlookup";
import { RootState } from "../types";
import { Rect as RectInterface } from "../types/rect";
const generatePlaceholder = () => {
  const users: Map<number, Map<number, number>> = new Map();
  for (let i = 0; i < 100; i++) {
    const weeks: Map<number, number> = new Map();
    for (let w = 0; w < 10; w++) {
      weeks.set(2020 * 100 + (w + 1), Math.floor(Math.random() * 4));
    }
    users.set(i, weeks);
  }
  return users;
};

const initialState: RectInterface = {
  users: generatePlaceholder(),
  index: 0,
};

const rectSlice = createSlice({
  name: "rectSlice",
  initialState: initialState,
  reducers: {
    incrementState: (
      state: RectInterface,
      action: PayloadAction<{ userid: number; yearweek: number }>
    ) => {
      let rect = getStatebyUserAndWeek(
        state.users,
        action.payload.userid,
        action.payload.userid
      );
      if (rect > -1) rect += 1;
      else if (rect === 4) rect = 0;
      let user = state.users.get(action.payload.userid);
      if (user !== undefined) user.set(action.payload.yearweek, rect);
    },
    setIndex: (state: RectInterface, action: PayloadAction<number>) => {
      state.index = action.payload;
    },
  },
});
export const { incrementState, setIndex } = rectSlice.actions;
export const rectReducer = rectSlice.reducer;
export const getAllUsers = (state: RootState) => {
  return state.rectReducer.users;
};
export const getIndex = (state: RootState) => {
  return state.rectReducer.index;
};
